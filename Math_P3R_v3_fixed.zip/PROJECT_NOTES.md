# Catatan Pengembangan (untuk dilanjutkan di sesi/AI/orang lain)

## Tujuan
Draft aplikasi matematika (Perbandingan Senilai & Berbalik Nilai). Fokus UI saat ini: tema Persona 3 Reload.
Kebutuhan fitur diturunkan dari wawancara kebutuhan siswa (kisi-kisi Cognitive Load, informan S01). Lihat bagian Versi 13.

## Keputusan desain
- Hanya pakai API inti React Native (Animated, Pressable, View, Text). Tidak ada library gradient/animasi tambahan.
- Animasi memakai `useNativeDriver: true` (hanya transform & opacity). Warna tidak dianimasikan.
- Lobby meniru menu pause P3R: panel putih kiri + teks vertikal, menu miring bertumpuk
  (item terpilih = pita merah, teks hitam; lainnya makin biru/redup), kartu portrait kanan atas,
  petunjuk tombol kanan bawah, latar bawah laut (`AnimatedBackground variant="sea"`).
- Karakter: `CHARACTER_IMAGE` = `assets/characters/makoto.png` (artwork Makoto baru, latar dihapus, bawah dipudarkan; animasi: melayang, goyang, aura & cincin berdenyut).
  Kredit ATLUS/SEGA tampil di lobby (`CHARACTER_CREDIT`). Jika diganti, sesuaikan `CHARACTER_ASPECT` di config. Siluet tampil bila nilainya `null`.
  Aset resmi berhak cipta Atlus/Sega -> jangan commit ke repo publik (sudah di .gitignore).

## Unsur matematika di latar (v3)
`src/components/MathBackdrop.js` dipakai oleh `AnimatedBackground` (varian `sea` dan `page`; UI lain tidak diubah):
- Kertas grafik bergeser pelan.
- Grafik `y = kx` (senilai, cyan) dan `x·y = k` (berbalik nilai, merah muda) dengan titik yang berjalan di kurva
  (warna sama dengan kartu di Materi). Hanya di lobby.
- Angka & rumus naik seperti gelembung (daftar `RISERS`; isi sesuai materi, ubah bebas).
Mode `rich` (khusus lobby) menambah: busur derajat berputar + jarum, gelombang sinus, diagram batang naik/turun
(senilai vs berbalik nilai), dan label rumus `x₁ : x₂ = y₁ : y₂` / `x₁ · y₁ = x₂ · y₂`.
Props: `grid`, `graph`, `rich`, `rising` (jumlah gelembung). Tetap hanya transform/opacity + `useNativeDriver`.

## Musik latar (v3)
- Isi `MUSIC_URL` di `src/config.js` dengan link YouTube; kosong = tombol disembunyikan.
- `MusicEngine.web.js` (iframe embed) dan `MusicEngine.js` (WebView, perlu `react-native-webview`) dipilih otomatis per platform.
- Musik baru mulai setelah tombol "BGM" ditekan (aturan autoplay browser) dan tetap jalan saat pindah layar.
- Diuji di web (build + klik). Versi Android/iOS belum diuji di perangkat.
- Perhatian hak cipta: lagu komersial (mis. soundtrack P3R) berhak cipta. Untuk rilis ke Play Store/App Store,
  pakai musik bebas royalti/berlisensi sendiri. Di build native, pakai file audio lokal (expo-av) alih-alih YouTube.

## Cara menambah menu / layar
1. Tambah item di `MENU` pada `src/config.js` (`screen: 'NAMA'`, hapus `locked`).
2. Buat `src/screens/Nama.js` (bungkus dengan `PageShell`).
3. Daftarkan di `App.js` (`{screen === 'NAMA' && <Nama onBack={home} />}`).

## Menu (v6) dan dasar desainnya
Dirancang dari temuan wawancara kebutuhan siswa (kisi-kisi cognitive load) dan Tabel 2 soal & kisi-kisi jawaban.
| Menu | Temuan yang dijawab | File |
|---|---|---|
| MATERI | siswa terbantu tabel + gambar panah | `screens/Materi.js` |
| BEDAKAN | sering tertukar senilai vs berbalik nilai (naik–naik vs naik–turun) | `screens/Bedakan.js` |
| LANGKAH | butuh contoh bertahap, satu langkah per layar, info penting ditandai | `screens/Langkah.js` |
| LATIHAN | soal Tabel 2 dipecah per tahap, petunjuk bertingkat, pembahasan saat salah, skor per tahap (2/1/0) | `screens/Latihan.js` |
| PROGRES | skor, jumlah petunjuk yang dipakai, soal yang perlu diulang | `screens/Progres.js` |
Isi soal/contoh ada di `src/data.js`. Kalimat soal sengaja pendek. Nama informan tidak dipakai (soal memakai nama "Rina").
Masuk dengan nama (`screens/Login.js`, tanpa kata sandi). Skor disimpan per nama lewat `utils/storage.js`:
localStorage di web (permanen di browser yang sama), hanya selama aplikasi terbuka di Android/iOS (perlu AsyncStorage untuk permanen).

## Latihan, Trophy & Profil (v7)
- `screens/Latihan.js` + `components/Quiz.js`: daftar misi (rank S/A/B/C, bar skor terbaik), HUD tahap (kotak progres berwarna sesuai poin, combo),
  pilihan jawaban A/B/C yang masuk bertahap + bergetar saat salah, petunjuk sebagai gelembung bicara Makoto, cap "BENAR!" + serpihan,
  layar hasil dengan banner `done_and_dusted.jpg`, rank, hitung naik skor, XP & level-up, dan trophy baru.
- `src/trophies.js`: daftar 10 trophy (perunggu/perak/emas/platinum), XP, level (nama level = Arcana, Lv 1-10), rank. Semua dihitung dari `progress`.
  Tambah trophy baru = tambah satu objek di `TROPHIES` (`test: (progress) => boolean`).
- `progress[idSoal]` kini: `{ score(terakhir), max, hints, best, attempts, clean, improved }`; `progress._trophies = { id: waktuBuka }`. Data lama tetap terbaca.
- `App.js`: `commit()` menerapkan perubahan lalu `awardTrophies()`. Trophy dari BEDAKAN tampil sebagai popup (`TrophyToast`) di layar mana pun.
- `screens/Profil.js` (menu PROFIL): banner + avatar, level/XP, statistik, rank per misi, grid trophy (ketuk = detail & cara membuka). Chip nama di Lobby juga menampilkan Lv + jumlah trophy dan bisa diketuk.
- `components/Fx.js`: Rise, Pop, PressScale, Burst, CountUp, Meter, useShake (hanya transform/opacity).
- Aset: `assets/characters/done_and_dusted.jpg` (banner) dan `makoto_avatar.jpg` (potongan wajah). Berhak cipta ATLUS/SEGA, sudah tercakup `.gitignore`.
- Belum diuji di perangkat/browser oleh pembuat (hanya cek sintaks + uji logika trophy). Cek tata letak di layar kecil.

## Pilih karakter (v9)
- Login: nama + jenis kelamin. Cowok = Makoto Yuki, cewek = Aigis. Pilihan disimpan per nama (`mp3r:gender:<nama>`) dan dikenali lagi saat nama yang sama diketik.
- Semua data karakter ada di `CHARACTERS` (`src/config.js`): gambar lobby (PNG transparan), banner hasil latihan, banner kepala di Profil, avatar, warna pita menu, kredit.
- Komponen membaca karakter aktif lewat `useChar()` (`src/CharacterContext.js`). Menambah karakter baru = tambah satu objek di `CHARACTERS` + aset.
- `aigis.png` adalah hasil potong otomatis dari art resmi (GrabCut) dan diperbesar dari 736x414, jadi agak lembut. Ganti dengan PNG transparan beresolusi tinggi bila ada.
- Performa: `src/perf.js` -> `LITE` (otomatis aktif di Android; ubah `PERF_MODE` di config). Mode ringan mengurangi gelembung rumus, bentuk, rumus papan tulis, dan mematikan busur derajat, gelombang sinus, & penggaris.
- Aset gambar sudah dikecilkan (total ~2 MB; hanya gambar karakter yang aktif yang dimuat).

## Versi 10: siap Android (Expo SDK 58)
- Naik dari SDK 49 ke **SDK 58**: Expo Go Play Store hanya mendukung SDK terbaru, SDK 49 tidak bisa dibuka lagi.
  `package.json` hanya memuat `expo`; library lain dipasang lewat `npm run setup` (`expo install`) agar versinya cocok.
- Web kini memakai Metro (`app.json` -> `web.bundler: metro`); `@expo/webpack-config` dihapus.
- Titik masuk `index.js` (`registerRootComponent`) menggantikan `expo/AppEntry.js`.
- Penyimpanan permanen: `utils/storage.js` memakai AsyncStorage di HP (dimuat sekali saat buka lewat `initStorage`, API `load/save` tetap sinkron).
- `App.js`: `SafeAreaProvider` + `SafeAreaView` dari `react-native-safe-area-context` (Android SDK baru edge-to-edge),
  `StatusBar` dari `expo-status-bar`, tombol Back Android ke lobby, musik dijeda saat app ke latar belakang.
- `Image resizeMode` dipindah ke `style` (prop lama deprecated).
- Ditambahkan ikon, `eas.json` (APK preview/development), `.vscode/extensions.json`, `PANDUAN_UJI_HP.md`.
- **Belum diuji**: paket ini disusun tanpa bisa menjalankan `npm install`/Expo. Jalankan `npm run doctor`
  dan cek daftar di `PANDUAN_UJI_HP.md`. Jika ada error versi, `npm run fix`.

## Versi 11: perbaikan tampilan HP (dari uji di Infinix, Expo Go)
- Lobby potret: karakter besar berdiri di depan panel putih (wajah ~36% lebar layar), panel putih lebih sempit (30%),
  menu lebih besar (font 9,2% lebar layar, jarak antar menu ditambah lewat prop `gap` di `LobbyMenu`), petunjuk menu dipindah di bawah menu.
  Aigis di potret memakai `aigis.png` (potongan transparan); artwork lebar `lobbyArt` hanya untuk lanskap.
- Chip nama lebih lebar di potret (teks Lv/trophy tidak terpotong); root Lobby `overflow: hidden`.
- Musik: WebView YouTube kini diletakkan di luar layar (opacity tidak menyembunyikannya di Android); error YouTube
  (mis. 152 = video melarang embed) terdeteksi dan tombol musik disembunyikan. Opsi baru `MUSIC_FILE` (file mp3 lokal lewat `expo-audio`, opsional).
- Ikon roda gigi di pojok kanan atas saat uji = menu Expo Go, tidak ada di APK.

## Status
- [x] Lobby bertema P3R + animasi, kredit ATLUS/SEGA
- [x] Materi, Bedakan, Langkah, Latihan (4 soal bertahap), Progres
- [x] Latar matematika + musik YouTube (draft)
- [x] Masuk dengan nama pengguna
- [x] Latihan interaktif, trophy (14), XP/level, layar Profil, latar matematika diperkaya (bentuk, rumus, garis bilangan, penggaris)
- [x] Penyimpanan progres permanen di HP (AsyncStorage)
- [ ] Sinkronisasi progres ke server (opsional)
- [ ] Validasi isi oleh ahli dan uji coba ke siswa
- [ ] Bank soal lebih banyak, jalur belajar adaptif

## Catatan teknis
- macOS: `EMFILE` -> `ulimit -n 10240` / watchman. Node 18/20 disarankan.
- Belum diuji visual di browser oleh pembuat awal; cek tata letak di berbagai ukuran layar.

## Versi 12: Makoto saja, lobby dirapikan, transisi halus
- Aigis dihapus total: blok `cewek` di `CHARACTERS`, pilihan gender di Login, logika `lobbyArt` di Lobby, aset `aigis*`. Hanya Makoto Yuki.
  Pilihan gender (`mp3r:gender:*`) tidak dipakai lagi; data lama di penyimpanan tidak mengganggu.
- Lobby (HP): petunjuk menu kini chip kecil (`HintChip`) tepat di bawah menu, tidak menimpa wajah karakter; teks bergeser halus saat ganti menu.
  Grafik y=kx / x·y=k di latar dikecilkan dan dipindah ke kanan bawah (opacity 0,45) agar tidak bertabrakan dengan menu.
- Transisi layar (`useScreenTransition` di `App.js`): layar lama memudar + geser keluar, layar baru masuk (maju = ke kiri, kembali ke lobby = ke kanan). Hanya opacity/transform.
  Semua pindah layar lewat `go(layar, back?)`; `jump()` tanpa animasi (dipakai di bawah layar intro login). Menu lobby masuk lebih cepat (tanpa efek back-overshoot).
- Musik: `MUSIC_URL = ''` (YouTube dimatikan). Jalur resmi = file lokal via `expo-audio` (sudah ada di `npm run setup`). `assets/music/bgm_original.mp3` = loop orisinal placeholder, belum diaktifkan. Lihat `assets/music/README.md`.
- Belum diuji di perangkat (tidak ada Expo di lingkungan penyusun); cek ulang tata letak chip di layar kecil.


## Versi 13: penyesuaian dengan tujuan wawancara (Cognitive Load) + permintaan siswa
Tema Persona 3 Reload TETAP dipertahankan (lobby, pita miring, Makoto, trophy, XP). Yang diubah adalah cara tema itu dipakai
di layar belajar, supaya tidak menambah extraneous load, dan fitur yang diminta siswa ditambahkan.

### Jejak keputusan: temuan wawancara -> fitur -> cara uji
| Kode | Temuan / permintaan siswa (S01) | Fitur | Cara uji |
|---|---|---|---|
| EL02/EL03, DS03 | Tampilan ramai berpotensi mengganggu (belum ditanyakan langsung ke siswa) | **Mode FOKUS** (`src/focus.js`): di Bedakan, Langkah, Latihan latar bergerak, combo, dan ledakan dimatikan; tombol bisa dimatikan. Lobby, Materi, Profil, hasil tetap bertema penuh | Tanyakan EL03/DS03 ke siswa; bandingkan fokus ON vs OFF |
| DS01 | "gambar ilustrasi objeknya" | `Pic` (emoji objek + keterangan) dekat teks soal di Bedakan, Langkah, Latihan | Wawancara kejelasan tampilan |
| DS03, GL01 | "tabel atau gambar" juga pada soal latihan | Tabel data di tiap soal Latihan (`TABEL` di data.js) | Amati apakah siswa memakai tabel saat menjawab |
| DS01, EL03 | "langkah bertahap, dipisah per layar", penjelasan pelan | Langkah satu per layar; di Bedakan bukti hitung dibuka belakangan | Amati apakah siswa tertinggal |
| Penutup | Contoh dekat kehidupan (bensin motor, patungan makanan) | Soal baru: Patungan Makanan, Beras di Warung, Pompa Air | Wawancara pasca-pakai |
| GL02, GL04 | Menjelaskan alasan membantu paham | Soal REFLEKSI "Mengapa?" di akhir 7 misi utama; "Jelaskan dulu" + penjelasan model di Langkah | Bandingkan kualitas penjelasan sebelum/sesudah |
| GL03 | Mandiri bila bantuan dikurangi bertahap | Bantuan memudar: Mudah/Menengah penuh, Sulit 1 petunjuk, Transfer 1 petunjuk dan 2 tahap | Catat petunjuk terpakai di PROGRES |
| GL05 | Transfer ke cerita berbeda | 3 misi bertanda TRANSFER (konteks baru, tahap lebih sedikit) | Skor transfer vs misi bertahap |
| IL03 | Prasyarat / variasi kemampuan | Misi **CEK AWAL** (3 soal): hasil menyarankan LANGKAH dulu atau lanjut ke Mudah | Bandingkan hasil cek awal dengan kinerja misi |

### Catatan teknis v13
- Data tambahan (PIC, TABEL, REFL, EXPLAIN) ada di bagian bawah `src/data.js` dan ditempelkan ke CASES/EXAMPLES/QUESTIONS.
- `PageShell` menerima prop `focusable`; `AnimatedBackground` punya varian `calm`.
- Misi `cek` bertipe `dasar` (tag kuning). Skor misi utama sekarang memuat 1 tahap refleksi, jadi `max` naik (mis. Pekerja dan Waktu 8 -> 10).
  Skor lama yang tersimpan di perangkat memakai max lama; hapus data lama bila ingin trophy dihitung ulang bersih.
- Belum diuji di perangkat. Cek: emoji tampil di Android, tombol FOKUS tidak menimpa tombol KEMBALI di layar sempit.

### Yang masih perlu (di luar kode)
- Validasi isi oleh ahli dan uji keterbacaan; tanya EL03 dan DS03 langsung ke siswa (efek visual: perlu atau mengganggu).
- Pertanyaan DS01 di lembar wawancara memuat kata "berbasis game"; sebaiknya dicatat sebagai pertanyaan yang agak menggiring.

## Versi 13: musik lokal + kontrol musik yang hilang sendiri
- `assets/music/bgm.mp3` (P5 "Beneath the Mask" rain, dipotong 8 menit/96 kbps dari versi 1 jam) aktif lewat `MUSIC_FILE`; `expo-audio` ada di `npm run setup`.
- `MusicButton`: ikon ♪ nyala/mati + volume − / + (5 segmen). Muncul 3,5 detik lalu memudar; ketuk pojok kanan bawah (44x44, tak terlihat) untuk memunculkan lagi. Posisi kanan bawah agar tidak menimpa tombol FOKUS di header.
- Musik mulai otomatis setelah login, jeda saat app ke latar belakang. Volume awal 60.
- Lagu berhak cipta: ganti sebelum rilis publik.

## Versi 14: rapikan Latihan, hapus SWITCH, Command, transisi
- Simbol UI tidak lagi memakai karakter font (▶ ◀ ▲ ▼ ✓ ✕ ↑ ↓ ◉ ◼ 💡): `src/components/Glyph.js` menggambarnya dengan View (`Tri`, `CheckMark`, `CrossMark`, `ArrowV`, `Box`, `Dot`). `Btn` punya prop `icon="right|left"`.
  Penyebab "acak-acakan": karakter itu jatuh ke font cadangan berbeda per HP (sebagian jadi emoji berwarna).
- `Pic` (ilustrasi emoji di soal): emoji diseragamkan, deretan panjang diringkas "emoji ×n", panah ➜ digambar. Teks di `data.js` tidak diubah.
- Tipografi Latihan/Quiz disamakan: soal 500, pertanyaan 700, pilihan 600, petunjuk 500; huruf pilihan tidak miring lagi.
- Lobby: tombol SWITCH dihapus (prop `onLogout` masih ada tetapi tidak dipakai; tidak ada cara logout di UI). Petunjuk menu = teks + garis bawah + label COMMAND di atas pita gelap miring (teks tidak ikut miring).
- Transisi layar: opacity hanya turun ke 0,55 (bukan 0) dan tanpa scale, animasi masuk menunggu 2 frame; tidak ada lagi kedip gelap.

## Fitur profil v2
- Profil sekarang punya **EDIT PROFILE** untuk memilih avatar dan banner dari daftar karakter di `src/config.js`.
- Pilihan profil disimpan per nama pengguna di AsyncStorage/localStorage.
- Profil punya **SHARE PROFILE** yang membuat kartu profil PNG berisi avatar, banner, level, XP, jumlah misi, dan trophy.
- Kartu dapat disimpan ke galeri atau dibagikan lewat share sheet Android.
- Untuk karakter tambahan, cukup tambahkan entry baru ke `CHARACTERS` di `src/config.js`; picker profil akan membacanya otomatis.
- Dependensi tambahan: `expo-media-library`, `expo-sharing`, `react-native-view-shot`. Jalankan `npm run setup` setelah mengambil project.

## Versi 15: SFX global, BGM per layar, tirai transisi, LAB, kartu profil P3R
- `src/audio.js`: `sfx('click'|'select'|'back'|'correct'|'wrong'|'swipe')` dipanggil dari `Btn`, `PressScale`, `LobbyMenu`, `PageShell`. `BGM` = peta lagu per layar (HOME, LATIHAN, MATERI, GAME, LAB); `App.js` memutar `LocalMusic key=<lagu>` sehingga lagu berganti saat masuk menu.
- Semua SFX dan `bgm_latihan/game/lab.mp3` dibuat orisinal lewat sintesis (placeholder). Untuk suara/lagu Persona sendiri: timpa file dengan NAMA SAMA di `assets/sfx/` dan `assets/music/` (berhak cipta Atlus/Sega; hanya untuk uji pribadi).
- `Curtain.js`: tirai miring P3R menutup, layar diganti saat tertutup, buka setelah `requestIdleCallback` selesai -> tidak ada lag terlihat.
- `screens/Lab.js` (menu LAB): stepper x, bar x/y, nilai tetap (y÷x atau x×y), "Tebak Dulu". Hasil tersimpan di `progress.lab`.
- Kartu SHARE PROFILE: pita merah/cyan miring, avatar belah ketupat, nama bergaya P3R.
- Belum diuji di perangkat.
