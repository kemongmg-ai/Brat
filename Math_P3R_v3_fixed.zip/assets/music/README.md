# Musik latar

File aktif: `bgm.mp3` (Persona 5 "Beneath the Mask" rain ambience, versi asli 1 jam dipotong jadi 8 menit, 96 kbps, supaya app tidak membengkak).
Diputar berulang lewat `expo-audio`; aktif lewat `MUSIC_FILE` di `src/config.js`.

Kontrol musik (komponen `MusicButton`): [−] [♪] [+] di kanan bawah, hilang sendiri setelah 3,5 detik tanpa disentuh.
Ketuk pojok kanan bawah layar untuk memunculkannya lagi. Ubah lama tampil lewat `HIDE_AFTER_MS`.

Ganti lagu: timpa `bgm.mp3` (nama sama) atau ubah path `require` di `src/config.js`.
Catatan: lagu ini berhak cipta Atlus/Sega. Aman untuk uji coba/skripsi pribadi, tetapi ganti dengan musik bebas royalti sebelum rilis publik (Play Store).
