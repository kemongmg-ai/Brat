import React, { useState } from 'react';
import { View, Text, Image, Pressable, Linking, StyleSheet } from 'react-native';
import { COLOR } from '../theme';
import PageShell, { Card } from '../components/PageShell';
import { ArrowTable, Btn } from '../components/Ui';
import { Rise, Pop } from '../components/Fx';
import { Tri } from '../components/Glyph';
import { useChar } from '../CharacterContext';

function Table({ heads, rows }) {
  return (
    <View style={{ marginBottom: 14 }}>
      <View style={s.row}>{heads.map((h) => <Text key={h} style={s.head}>{h}</Text>)}</View>
      {rows.map((r, i) => (
        <View key={i} style={s.row}>{r.map((c, j) => <Text key={j} style={s.cell}>{c}</Text>)}</View>
      ))}
    </View>
  );
}

const STEPS = ['Konsep', 'Senilai', 'Berbalik', 'Cek cepat', 'Rujukan', 'Siap'];

function P({ children, strong }) {
  return <Text style={[s.desc, strong && { fontWeight: '800', color: COLOR.ice }]}>{children}</Text>;
}
function Formula({ children, color = COLOR.cyan }) {
  return <View style={[s.formula, { borderColor: color }]}><Text style={[s.formulaT, { color }]}>{children}</Text></View>;
}

function Concept() {
  return (
    <View>
      <Card title="Mulai dari besaran" accent={COLOR.ice}>
        <P>Besaran adalah sesuatu yang bisa dihitung atau diukur, misalnya banyak barang, harga, jarak, waktu, atau jumlah pekerja. Dalam satu soal cerita biasanya ada dua besaran yang saling terhubung. Mengubah yang satu akan ikut mengubah yang lain.</P>
        <P>Perbandingan membantu kita menjawab: kalau besaran pertama berubah, besaran kedua menjadi berapa? Kunci pertama selalu sama: tentukan dulu jenis hubungannya, baru menghitung.</P>
        <P strong>Tanyakan: apa yang tetap (konstan) di antara kedua besaran ini?</P>
      </Card>

      <Card no="A" title="Senilai: yang tetap adalah hasil bagi">
        <P>Dua besaran disebut senilai jika keduanya naik bersama atau turun bersama dengan laju yang sama. Contohnya harga dan jumlah barang: beli 2 kali lebih banyak, bayar 2 kali lebih banyak.</P>
        <Formula>b ÷ a selalu sama  (b = k × a)</Formula>
        <P>Angka k disebut konstanta perbandingan, yaitu harga satuan, jarak per liter, atau sejenisnya. Pada grafik, titik-titiknya membentuk garis lurus yang melewati titik (0, 0). Kalau tidak ada barang, tidak ada harga.</P>
        <P>Contoh sehari-hari: harga dan jumlah barang, bensin dan jarak, bahan kue dan jumlah porsi, gaji dan jam kerja.</P>
      </Card>

      <Card no="B" title="Berbalik nilai: yang tetap adalah hasil kali" accent={COLOR.accent}>
        <P>Dua besaran disebut berbalik nilai jika yang satu naik, yang lain turun, dan hasil kali keduanya tetap. Ada "total" yang harus dibagi: beban kerja, jarak, atau uang patungan.</P>
        <Formula color={COLOR.accent}>a × b selalu sama  (b = k ÷ a)</Formula>
        <P>Pada grafik, titik-titiknya membentuk kurva menurun yang makin mendatar dan tidak melewati (0, 0). Kalau pekerja sangat banyak, hari yang dibutuhkan mendekati nol tetapi tidak pernah benar-benar nol.</P>
        <P>Contoh sehari-hari: pekerja dan lama pengerjaan, laju dan waktu tempuh (jarak tetap), jumlah orang dan iuran (harga tetap), persediaan makanan dan lama habisnya.</P>
      </Card>

      <Card title="Kesalahan yang sering terjadi" accent="#FFD400">
        <P>1. Mengira semua soal "makin banyak" adalah senilai. Periksa dulu arah besaran kedua: ikut naik, atau justru turun?</P>
        <P>2. Memakai "aturan silang" tanpa tahu jenisnya. Rumus silang yang sama bisa menghasilkan jawaban salah kalau jenis hubungannya keliru. Penelitian tentang miskonsepsi siswa kelas VII menunjukkan hal ini cukup umum.</P>
        <P>3. Lupa menguji jawaban. Setelah menghitung, tanya: apakah hasilnya masuk akal? Pekerja bertambah tetapi hari ikut bertambah tentu ada yang keliru.</P>
        <P>4. Salah memasangkan angka. Pastikan angka yang sejenis (misalnya liter dengan liter) berada di kolom yang sama.</P>
      </Card>
    </View>
  );
}

const REFS = [
  { t: 'Matematika untuk SMP/MTs Kelas VII (Buku Siswa, Kurikulum Merdeka)', by: 'Kemendikbudristek, penyadur: Sugiman & Achmad Dany Fachrudin. Memuat bab perbandingan senilai dan berbalik nilai.', url: 'https://static.buku.kemdikbud.go.id/content/pdf/bukuteks/kurikulum21/MATEMATIKA-BS-KLS%20VII.pdf' },
  { t: 'Matematika SMP/MTs Kelas VII Semester 2 (Buku Siswa, Kurikulum 2013)', by: 'Kementerian Pendidikan dan Kebudayaan RI. Buku teks resmi, tersedia gratis di Buku Sekolah Elektronik.', url: 'https://static.buku.kemdikbud.go.id/content/pdf/bukuteks/k13/bukusiswa/Matematika%20Sm2%20SMP%20Kelas%207%20BS%20press.pdf' },
  { t: 'Direct and inverse variation (Algebra II)', by: 'Khan Academy. Video berbahasa Inggris tentang y = kx dan y = k/x, cocok untuk memperdalam.', url: 'https://www.khanacademy.org/math/algebra-home/alg-rational-expr-eq-func/alg-direct-and-inverse-variation/v/direct-and-inverse-variation' },
  { t: 'Studi Literatur: Miskonsepsi Siswa Kelas VII pada Konsep Perbandingan Senilai dan Berbalik Nilai', by: 'Artikel jurnal ilmiah tentang kesalahan umum siswa, termasuk memakai prosedur mekanis tanpa memahami konsep.', url: 'https://ejurnal.univamedan.ac.id/index.php/jkpm/article/download/1084/772/3336' },
];

function Refs() {
  return (
    <Card title="Rujukan & bacaan lanjutan" accent={COLOR.ice}>
      <Text style={s.desc}>Isi materi ini merangkum konsep umum perbandingan senilai dan berbalik nilai. Untuk bahasan yang lebih lengkap, baca sumber di bawah (ketuk untuk membuka).</Text>
      {REFS.map((r, i) => (
        <Pressable key={r.url} onPress={() => Linking.openURL(r.url)} style={s.ref}>
          <Text style={s.refNo}>{i + 1}</Text>
          <View style={{ flex: 1 }}>
            <Text style={s.refT}>{r.t}</Text>
            <Text style={s.refBy}>{r.by}</Text>
            <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 6 }}><Text style={[s.refGo, { marginTop: 0 }]}>BUKA TAUTAN</Text><Tri dir="right" size={8} color={COLOR.cyan} style={{ marginLeft: 8 }} /></View>
          </View>
        </Pressable>
      ))}
    </Card>
  );
}

function Direct() {
  return (
    <Card no="1" title="Contoh senilai: bensin & jarak">
      <Text style={s.desc}>Konteks: bensin dan jarak tempuh. Bensin makin banyak, jarak makin jauh.</Text>
      <Table heads={['Bensin (L)', 'Jarak (km)']} rows={[['3  (↑ naik)', '45  (↑ naik)'], ['8  (↑ naik)', '120  (↑ naik)']]} />
      <ArrowTable cols={[{ name: 'Bensin (L)', v: [3, 8], dir: 'up' }, { name: 'Jarak (km)', v: [45, 120], dir: 'up' }]} />
      <Text style={[s.logic, { color: COLOR.cyan }]}>Bensin bertambah, jarak ikut bertambah.</Text>
      <Text style={s.rule}>Hasil bagi selalu sama: 45 ÷ 3 = 120 ÷ 8 = 15</Text>
    </Card>
  );
}

function Inverse() {
  return (
    <Card no="2" title="Contoh berbalik nilai: pekerja & waktu" accent={COLOR.accent}>
      <Text style={s.desc}>Konteks: pekerja dan waktu bangunan. Pekerja makin banyak, hari makin sedikit.</Text>
      <Table heads={['Pekerja (orang)', 'Waktu (hari)']} rows={[['15  (↑ naik)', '14  (↓ turun)'], ['21  (↑ naik)', '10  (↓ turun)']]} />
      <ArrowTable cols={[{ name: 'Pekerja (orang)', v: [15, 21], dir: 'up' }, { name: 'Waktu (hari)', v: [14, 10], dir: 'down' }]} />
      <Text style={[s.logic, { color: COLOR.accent }]}>Pekerja ditambah, waktu selesai makin cepat.</Text>
      <Text style={s.rule}>Hasil kali selalu sama: 15 × 14 = 21 × 10 = 210</Text>
    </Card>
  );
}

function Quick() {
  const items = [
    ['Tandai', 'Tandai dua besaran di soal.'],
    ['Tanya', 'Kalau yang satu NAIK, yang satunya naik atau turun?'],
    ['Putuskan', 'Naik–naik: SENILAI (hasil bagi sama). Naik–turun: BERBALIK NILAI (hasil kali sama).'],
    ['Cek', 'Apakah jawabannya masuk akal?'],
  ];
  return (
    <Card no="3" title="Cara Cepat Membedakan" accent="#FFD400">
      {items.map(([k, v], i) => (
        <Rise key={k} delay={i * 90} style={s.qRow}>
          <View style={s.qKey}><Text style={s.qKeyT}>{k}</Text></View>
          <Text style={[s.desc, { flex: 1, marginBottom: 0 }]}>{v}</Text>
        </Rise>
      ))}
    </Card>
  );
}

function Ready({ onPractice, onReview }) {
  const ch = useChar();
  return (
    <Pop>
      <View style={[s.ready, { borderColor: ch.tint }]}>
        <Image source={ch.avatar} style={[s.av, { borderColor: ch.tint }]} />
        <Text style={[s.readyName, { color: ch.tint }]}>{ch.name}</Text>
        <Text style={s.readyT}>Kamu sudah tahu dua jenisnya dan cara membedakannya. Latihan bikin makin hafal.</Text>
        <Btn label="MULAI LATIHAN" icon="right" tone="cyan" onPress={onPractice} style={{ alignSelf: 'stretch' }} />
        <Btn label="ULANGI DARI AWAL" onPress={onReview} style={{ alignSelf: 'stretch', marginTop: 10 }} />
      </View>
    </Pop>
  );
}

export default function Materi({ onBack, onPractice }) {
  const [k, setK] = useState(0);
  const last = k === STEPS.length - 1;
  return (
    <PageShell title="Materi" onBack={onBack}>
      <View style={s.prog}>
        {STEPS.map((n, i) => (
          <View key={n} style={{ flex: 1, marginRight: i < STEPS.length - 1 ? 6 : 0 }}>
            <View style={[s.seg, { backgroundColor: i <= k ? COLOR.cyan : 'rgba(255,255,255,0.16)' }]} />
            <Text style={[s.segT, { opacity: i === k ? 1 : 0.5 }]} numberOfLines={1}>{n}</Text>
          </View>
        ))}
      </View>

      <View key={k}>
        <Rise from={30} axis="x">
          {k === 0 && <Concept />}
          {k === 1 && <Direct />}
          {k === 2 && <Inverse />}
          {k === 3 && <Quick />}
          {k === 4 && <Refs />}
        </Rise>
        {last && <Ready onPractice={onPractice} onReview={() => setK(0)} />}
      </View>

      {!last && (
        <View style={s.nav}>
          <Btn label="SEBELUMNYA" icon="left" onPress={() => setK(k - 1)} disabled={k === 0} style={{ flex: 1, marginRight: 10 }} />
          <Btn label="LANJUT" icon="right" tone="cyan" onPress={() => setK(k + 1)} style={{ flex: 1 }} />
        </View>
      )}
    </PageShell>
  );
}

const s = StyleSheet.create({
  formula: { borderLeftWidth: 5, paddingVertical: 8, paddingHorizontal: 12, marginBottom: 14, backgroundColor: 'rgba(2,12,27,0.55)' },
  formulaT: { fontSize: 16, fontWeight: '900', fontStyle: 'italic' },
  ref: { flexDirection: 'row', borderTopWidth: 1, borderTopColor: 'rgba(255,255,255,0.14)', paddingVertical: 12 },
  refNo: { color: COLOR.cyan, fontSize: 20, fontWeight: '900', fontStyle: 'italic', width: 30 },
  refT: { color: COLOR.white, fontSize: 14, fontWeight: '800', lineHeight: 20 },
  refBy: { color: COLOR.text, opacity: 0.75, fontSize: 12, lineHeight: 18, marginTop: 3 },
  refGo: { color: COLOR.cyan, fontSize: 11, fontWeight: '900', letterSpacing: 2, marginTop: 6 },
  prog: { flexDirection: 'row', marginBottom: 20 },
  seg: { height: 6, transform: [{ skewX: '-20deg' }] },
  segT: { color: COLOR.ice, fontSize: 10, fontWeight: '800', marginTop: 6 },
  desc: { color: COLOR.white, fontSize: 14, marginBottom: 14, lineHeight: 22, opacity: 0.9 },
  row: { flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.12)', paddingVertical: 10 },
  head: { flex: 1, color: COLOR.white, fontWeight: '900', fontSize: 14 },
  cell: { flex: 1, color: COLOR.text, fontSize: 14 },
  rule: { marginTop: 8, color: COLOR.ice, fontSize: 13, fontWeight: '700' },
  logic: { marginTop: 14, fontStyle: 'italic', fontSize: 14, fontWeight: '800' },
  qRow: { flexDirection: 'row', alignItems: 'flex-start', marginBottom: 14 },
  qKey: { width: 74, backgroundColor: '#FFD400', paddingVertical: 3, alignItems: 'center', marginRight: 12, transform: [{ skewX: '-12deg' }] },
  qKeyT: { color: COLOR.navy, fontWeight: '900', fontSize: 13, transform: [{ skewX: '12deg' }] },
  nav: { flexDirection: 'row', marginTop: 4 },
  ready: { borderWidth: 2, padding: 22, alignItems: 'center', backgroundColor: COLOR.glass },
  av: { width: 84, height: 84, borderRadius: 42, borderWidth: 3 },
  readyName: { fontSize: 15, fontWeight: '900', fontStyle: 'italic', letterSpacing: 2, marginTop: 10 },
  readyT: { color: COLOR.white, fontSize: 15, lineHeight: 23, textAlign: 'center', marginVertical: 14 },
});
