import React, { useEffect, useMemo, useRef, useState } from 'react';
import { View, Text, Pressable, StyleSheet, Animated } from 'react-native';
import PageShell, { Card } from '../components/PageShell';
import { ArrowTable, Btn, Tag } from '../components/Ui';
import { ArrowV, Tri } from '../components/Glyph';
import { COLOR } from '../theme';
import { CASES } from '../data';

// Game dirancang sebagai latihan singkat berbentuk misi: visual dulu, hitungan belakangan.
// Tidak memakai timer agar permainan tidak menambah beban yang tidak diperlukan.
const ROUNDS = [0, 1, 3, 2, 5, 4];

function Choice({ label, sub, active, correct, wrong, onPress, disabled }) {
  return (
    <Pressable
      disabled={disabled}
      onPress={onPress}
      style={[s.choice, active && s.choiceActive, correct && s.choiceCorrect, wrong && s.choiceWrong]}
    >
      <Text style={[s.choiceLabel, active && { color: COLOR.navy }]}>{label}</Text>
      <Text style={[s.choiceSub, active && { color: '#16325F' }]}>{sub}</Text>
    </Pressable>
  );
}

function ArrowMini({ dir, color }) {
  return (
    <View style={s.arrowWrap}>
      <ArrowV dir={dir} size={28} color={color} />
    </View>
  );
}

export default function Game({ onBack, onResult }) {
  const rounds = useMemo(() => ROUNDS.map((i) => CASES[i]), []);
  const [round, setRound] = useState(0);
  const [pick, setPick] = useState(null);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [bestStreak, setBestStreak] = useState(0);
  const [hint, setHint] = useState(false);
  const [done, setDone] = useState(false);
  const [mode, setMode] = useState('hub');
  const [mini, setMini] = useState({i:0, pick:null, score:0, done:false});
  const cardIn = useRef(new Animated.Value(0)).current;
  const feedbackIn = useRef(new Animated.Value(0)).current;
  const scorePop = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    cardIn.setValue(0);
    Animated.spring(cardIn, { toValue: 1, friction: 7, tension: 85, useNativeDriver: true }).start();
  }, [round, cardIn]);

  const c = rounds[round];
  const answered = pick !== null;
  const correct = answered && pick === c.ans;

  useEffect(() => {
    if (!answered) return;
    feedbackIn.setValue(0);
    Animated.spring(feedbackIn, { toValue: 1, friction: 8, tension: 90, useNativeDriver: true }).start();
  }, [answered, feedbackIn]);

  const choose = (value) => {
    if (answered) return;
    const ok = value === c.ans;
    setPick(value);
    if (ok) {
      setScore((v) => v + (hint ? 5 : 10));
      scorePop.setValue(1.18);
      Animated.spring(scorePop, { toValue: 1, friction: 5, tension: 160, useNativeDriver: true }).start();
      setStreak((v) => {
        const n = v + 1;
        setBestStreak((b) => Math.max(b, n));
        return n;
      });
    } else {
      setStreak(0);
    }
  };

  const next = () => {
    if (round + 1 >= rounds.length) {
      const result = { score, max: rounds.length * 10, rounds: rounds.length, bestStreak };
      setDone(true);
      onResult && onResult(result);
      return;
    }
    setRound((v) => v + 1);
    setPick(null);
    setHint(false);
  };

  const restart = () => {
    setRound(0); setPick(null); setScore(0); setStreak(0); setBestStreak(0); setHint(false); setDone(false);
  };


  // Hub: pilih cara belajar. Semua mode tetap tanpa timer agar fokus ke penalaran.
  if (mode === 'hub') {
    const modes = [
      {k:'relasi', title:'MISI RELASI', sub:'Baca arah panah: senilai atau berbalik nilai?', col:COLOR.cyan},
      {k:'jenis', title:'TEBAK JENIS', sub:'Identifikasi jenis perbandingan sebelum menghitung.', col:'#FFD400'},
      {k:'tabel', title:'SUSUN TABEL', sub:'Lengkapi tabel dan temukan pola hubungan besaran.', col:'#FF4D8D'},
    ];
    return <PageShell title="Game" onBack={onBack} focusable>
      <Text style={s.kicker}>PETA MINI-GAME</Text>
      <Text style={s.title}>PILIH MISIMU</Text>
      <Text style={s.body}>Setiap mode melatih langkah berpikir yang berbeda. Tidak ada timer.</Text>
      {modes.map(m => <Pressable key={m.k} onPress={()=>{setMode(m.k); setMini({i:0,pick:null,score:0,done:false});}} style={[s.modeCard,{borderColor:m.col}]}>
        <Text style={[s.modeTitle,{color:m.col}]}>{m.title}</Text><Text style={s.modeSub}>{m.sub}</Text>
      </Pressable>)}
    </PageShell>;
  }

  if (mode === 'jenis' || mode === 'tabel') {
    const data = mode === 'jenis' ? [
      {q:'2 buku seharga Rp10.000. 4 buku seharga Rp20.000. Hubungannya?', opts:['SENILAI','BERBALIK NILAI'], ans:'SENILAI', why:'Jumlah buku naik dan harga juga naik dengan pola yang sama.'},
      {q:'4 pekerja selesai 12 hari. Jika pekerja bertambah, waktu cenderung...', opts:['NAIK','TURUN'], ans:'TURUN', why:'Untuk pekerjaan yang sama, semakin banyak pekerja, waktu yang dibutuhkan semakin sedikit.'},
      {q:'Jarak motor bertambah dari 45 km menjadi 120 km. Bensin yang diperlukan ikut...', opts:['NAIK','TURUN'], ans:'NAIK', why:'Dalam konteks ini jarak dan bensin bertambah bersama.'},
    ] : [
      {q:'2 buku → Rp10.000. 4 buku → ?', opts:['Rp5.000','Rp20.000','Rp40.000'], ans:'Rp20.000', why:'Jumlah buku ×2, maka harga juga ×2.'},
      {q:'4 pekerja → 12 hari. 8 pekerja → ?', opts:['6 hari','24 hari','16 hari'], ans:'6 hari', why:'Pekerja ×2, sehingga waktu menjadi setengahnya.'},
      {q:'45 km → 3 L. 120 km → ?', opts:['5 L','8 L','10 L'], ans:'8 L', why:'120/45 bukan pola langsung yang nyaman; dari 15 km per 1 L, 120 km membutuhkan 8 L.'},
    ];
    const d=data[mini.i], answered=mini.pick!==null, ok=mini.pick===d.ans;
    if(mini.done) return <PageShell title="Game" onBack={onBack} focusable><Card title="MISI SELESAI" accent={mode==='jenis'?'#FFD400':'#FF4D8D'}><Text style={s.finalScore}>{mini.score}<Text style={s.finalMax}> / {data.length*10}</Text></Text><Text style={s.body}>Bagus. Coba mode lain untuk melatih konsep dari sudut berbeda.</Text><Btn label="KEMBALI KE PETA" onPress={()=>setMode('hub')} tone="cyan" /></Card></PageShell>;
    const choose=(v)=>{if(answered)return; setMini(x=>({...x,pick:v,score:x.score+(v===d.ans?10:0)}));};
    return <PageShell title="Game" onBack={()=>setMode('hub')} focusable>
      <Text style={s.kicker}>{mode==='jenis'?'TEBAK JENIS':'SUSUN TABEL'}</Text><Text style={s.title}>RONDE {mini.i+1}/{data.length}</Text>
      <Card title={mode==='jenis'?'Tentukan hubungan dulu':'Lengkapi pola besaran'} accent={mode==='jenis'?'#FFD400':'#FF4D8D'}>
        <Text style={s.story}>{d.q}</Text>
        {mode==='tabel' && <View style={s.tableMini}><Text style={s.tableHead}>BESARAN 1</Text><Text style={s.tableHead}>BESARAN 2</Text><Text style={s.tableCell}>{mini.i===0?'2 buku':mini.i===1?'4 pekerja':'45 km'}</Text><Text style={s.tableCell}>{mini.i===0?'Rp10.000':mini.i===1?'12 hari':'3 L'}</Text><Text style={s.tableCell}>{mini.i===0?'4 buku':mini.i===1?'8 pekerja':'120 km'}</Text><Text style={s.tableCell}>?</Text></View>}
        <View style={s.choices}>{d.opts.map(o=><Choice key={o} label={o} sub="pilih jawaban" active={mini.pick===o} correct={answered&&o===d.ans} wrong={answered&&mini.pick===o&&o!==d.ans} onPress={()=>choose(o)} disabled={answered}/>)}</View>
        {answered && <View style={[s.feedback,{borderColor:ok?COLOR.cyan:COLOR.accent}]}><Text style={[s.feedbackTitle,{color:ok?COLOR.cyan:COLOR.accent}]}>{ok?'TEPAT!':'BELUM TEPAT'}</Text><Text style={s.body}>{d.why}</Text><Btn label={mini.i+1===data.length?'SELESAI':'RONDE BERIKUTNYA'} icon="right" tone="cyan" onPress={()=>mini.i+1===data.length?setMini(x=>({...x,done:true})):setMini(x=>({...x,i:x.i+1,pick:null}))}/></View>}
      </Card>
    </PageShell>;
  }

  if (mode === 'relasi' && !done) {
    // continue to the original Misi Relasi UI below
  }

  if (done) {
    const pct = Math.round((score / (rounds.length * 10)) * 100);
    return (
      <PageShell title="Game" onBack={onBack} focusable>
        <Card title="MISI SELESAI" accent={COLOR.cyan}>
          <Text style={s.finalScore}>{score} <Text style={s.finalMax}>/ {rounds.length * 10}</Text></Text>
          <Text style={s.finalTitle}>{pct >= 80 ? 'RASIO MASTER' : pct >= 50 ? 'PEMBURU RASIO' : 'MURID DARK HOUR'}</Text>
          <Text style={s.body}>Streak terbaik: {bestStreak}. Coba lagi untuk memperbaiki skor tanpa terburu-buru.</Text>
          <Btn label="MAIN LAGI" onPress={restart} tone="cyan" />
          <Btn label="LANJUT KE LATIHAN" onPress={() => onBack()} style={{ marginTop: 10 }} />
        </Card>
      </PageShell>
    );
  }

  return (
    <PageShell title="Game" onBack={onBack} focusable>
      <View style={s.header}>
        <View>
          <Text style={s.kicker}>MISI RELASI</Text>
          <Text style={s.title}>NAIK–NAIK atau NAIK–TURUN?</Text>
        </View>
        <View style={s.scoreBox}>
          <Text style={s.scoreLabel}>SKOR</Text>
          <Animated.Text style={[s.score, { transform: [{ scale: scorePop }] }]}>{score}</Animated.Text>
          {streak > 1 && <Text style={s.combo}>COMBO ×{streak}</Text>}
        </View>
      </View>

      <View style={s.progressRow}>
        {rounds.map((_, i) => <View key={i} style={[s.progressDot, i <= round && { backgroundColor: COLOR.cyan }]} />)}
      </View>

      <Animated.View style={{ opacity: cardIn, transform: [{ translateY: cardIn.interpolate({ inputRange: [0,1], outputRange: [22,0] }) }, { scale: cardIn.interpolate({ inputRange: [0,1], outputRange: [0.98,1] }) }] }}>
      <Card no={`${round + 1}/${rounds.length}`} title="Pilih hubungan kedua besaran" accent={c.ans === 'senilai' ? COLOR.cyan : COLOR.accent}>
        <Text style={s.story}>{c.story}</Text>

        <View style={s.visualCard}>
          <View style={s.col}>
            <Text style={s.colName}>{c.cols[0].name}</Text>
            <Text style={s.value}>{c.cols[0].v[0]}</Text>
            <ArrowMini dir={c.cols[0].dir} color={COLOR.cyan} />
            <Text style={s.value}>{c.cols[0].v[1]}</Text>
          </View>
          <View style={s.link}><View style={s.linkLine} /><Tri dir="right" size={7} color="rgba(255,255,255,0.5)" /></View>
          <View style={s.col}>
            <Text style={s.colName}>{c.cols[1].name}</Text>
            <Text style={s.value}>{c.cols[1].v[0]}</Text>
            <ArrowMini dir={c.cols[1].dir} color={COLOR.accent} />
            <Text style={s.value}>{c.cols[1].v[1]}</Text>
          </View>
        </View>

        {!answered && <Text style={s.prompt}>Lihat arah panahnya. Jangan hitung dulu.</Text>}

        <View style={s.choices}>
          <Choice
            label="SENILAI"
            sub="naik–naik / turun–turun"
            active={pick === 'senilai'}
            correct={answered && c.ans === 'senilai'}
            wrong={answered && pick === 'senilai' && c.ans !== 'senilai'}
            onPress={() => choose('senilai')}
            disabled={answered}
          />
          <Choice
            label="BERBALIK NILAI"
            sub="naik–turun"
            active={pick === 'berbalik'}
            correct={answered && c.ans === 'berbalik'}
            wrong={answered && pick === 'berbalik' && c.ans !== 'berbalik'}
            onPress={() => choose('berbalik')}
            disabled={answered}
          />
        </View>

        {!answered && !hint && <Btn label="BUTUH PETUNJUK?" onPress={() => setHint(true)} />}
        {hint && !answered && <Text style={s.hint}>Petunjuk: kalau satu besaran naik, perhatikan apakah yang lain ikut naik atau justru turun.</Text>}

        {answered && (
          <Animated.View style={[s.feedback, { borderColor: correct ? COLOR.cyan : COLOR.accent, opacity: feedbackIn, transform: [{ translateY: feedbackIn.interpolate({ inputRange: [0,1], outputRange: [12,0] }) }] }]}>
            <Text style={[s.feedbackTitle, { color: correct ? COLOR.cyan : COLOR.accent }]}>{correct ? 'TEPAT! +' + (hint ? 5 : 10) : 'BELUM TEPAT'}</Text>
            <Tag type={c.ans} />
            <ArrowTable cols={c.cols} />
            <Text style={s.body}>{c.why}</Text>
            {!correct && <Text style={s.body}>Tidak apa-apa. Fokus pada arah panah, lalu coba lagi di ronde berikutnya.</Text>}
            <Btn label={round + 1 === rounds.length ? 'LIHAT HASIL' : 'RONDE BERIKUTNYA'} icon="right" onPress={next} tone="cyan" />
          </Animated.View>
        )}
      </Card>
      </Animated.View>
    </PageShell>
  );
}

const s = StyleSheet.create({
  modeCard: { borderWidth: 2, backgroundColor: 'rgba(3,26,74,0.82)', padding: 16, marginTop: 12 },
  modeTitle: { fontSize: 18, fontWeight: '900', fontStyle: 'italic' },
  modeSub: { color: COLOR.text, fontSize: 12, lineHeight: 18, marginTop: 5 },
  tableMini: { flexDirection:'row', flexWrap:'wrap', borderWidth:1, borderColor:'rgba(255,255,255,0.2)', marginTop:14 },
  tableHead: { width:'50%', padding:8, color:COLOR.cyan, fontSize:10, fontWeight:'900', borderBottomWidth:1, borderColor:'rgba(255,255,255,0.15)' },
  tableCell: { width:'50%', padding:10, color:COLOR.white, fontSize:14, fontWeight:'800', borderBottomWidth:1, borderColor:'rgba(255,255,255,0.1)' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  kicker: { color: COLOR.cyan, fontSize: 10, fontWeight: '900', letterSpacing: 2.5 },
  title: { color: COLOR.white, fontSize: 19, fontWeight: '900', fontStyle: 'italic', marginTop: 2 },
  scoreBox: { borderWidth: 2, borderColor: COLOR.cyan, paddingHorizontal: 12, paddingVertical: 5, alignItems: 'center', minWidth: 70 },
  scoreLabel: { color: COLOR.ice, fontSize: 8, fontWeight: '900', letterSpacing: 2 },
  score: { color: COLOR.cyan, fontSize: 22, fontWeight: '900' },
  combo: { color: '#FFD45C', fontSize: 9, fontWeight: '900', letterSpacing: 1.5, marginTop: 2 },
  progressRow: { flexDirection: 'row', marginBottom: 16 },
  progressDot: { flex: 1, height: 6, marginRight: 5, backgroundColor: 'rgba(255,255,255,0.14)', transform: [{ skewX: '-15deg' }] },
  story: { color: COLOR.white, fontSize: 16, lineHeight: 24, fontWeight: '700' },
  visualCard: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around', marginTop: 16, padding: 12, borderWidth: 1, borderColor: 'rgba(255,255,255,0.16)', backgroundColor: 'rgba(2,12,27,0.7)' },
  col: { alignItems: 'center', flex: 1 },
  colName: { color: COLOR.ice, fontSize: 11, fontWeight: '900', textAlign: 'center', marginBottom: 7 },
  value: { color: COLOR.white, fontSize: 18, fontWeight: '900' },
  arrowWrap: { height: 26, justifyContent: 'center' },
  link: { width: 42, height: 20, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', opacity: 0.8 },
  linkLine: { width: 26, height: 2, backgroundColor: 'rgba(255,255,255,0.5)' },
  prompt: { color: COLOR.cyan, fontSize: 12, fontWeight: '800', fontStyle: 'italic', marginTop: 12 },
  choices: { flexDirection: 'row', flexWrap: 'wrap', marginTop: 12 },
  choice: { flexGrow: 1, flexBasis: 150, borderWidth: 2, borderColor: 'rgba(255,255,255,0.2)', backgroundColor: 'rgba(3,26,74,0.8)', padding: 13, marginRight: 8, marginBottom: 8 },
  choiceActive: { backgroundColor: COLOR.white, borderColor: COLOR.white },
  choiceCorrect: { borderColor: COLOR.cyan },
  choiceWrong: { borderColor: COLOR.accent },
  choiceLabel: { color: COLOR.white, fontSize: 15, fontWeight: '900', fontStyle: 'italic' },
  choiceSub: { color: COLOR.ice, fontSize: 11, marginTop: 4, fontWeight: '700' },
  hint: { color: '#FFD400', fontSize: 13, lineHeight: 20, fontWeight: '700', marginVertical: 8 },
  feedback: { borderWidth: 2, padding: 14, marginTop: 10, backgroundColor: 'rgba(2,12,27,0.65)' },
  feedbackTitle: { fontSize: 17, fontWeight: '900', fontStyle: 'italic', letterSpacing: 1.5, marginBottom: 8 },
  body: { color: COLOR.text, fontSize: 13, lineHeight: 21, marginTop: 10 },
  finalScore: { color: COLOR.cyan, fontSize: 58, fontWeight: '900', fontStyle: 'italic' },
  finalMax: { color: COLOR.ice, fontSize: 24 },
  finalTitle: { color: COLOR.white, fontSize: 18, fontWeight: '900', letterSpacing: 2, marginTop: 2 },
});
