import React, { useState } from 'react';
import { View, Text, Pressable, StyleSheet } from 'react-native';
import { COLOR } from '../theme';
import PageShell, { Card } from '../components/PageShell';
import { Rise, Pop, PressScale } from '../components/Fx';
import { Tag, fmt } from '../components/Ui';
import { sfx } from '../audio';

// LAB: geser nilai x, lihat y berubah secara langsung. Menjawab temuan "siswa tertukar naik-naik vs naik-turun".
const MODES = {
  senilai: {
    color: COLOR.cyan, title: 'Bensin Motor', xs: [1, 2, 3, 4, 5, 6, 8, 10],
    xl: 'Bensin (liter)', yl: 'Jarak (km)', y: (x) => 40 * x, k: 'y ÷ x = 40', max: 400,
    story: '1 liter bensin dapat menempuh 40 km.',
    ask: 'Bensin dijadikan 2 kali lipat. Jaraknya jadi?', right: 0,
    why: 'Senilai: x naik, y ikut naik. Hasil bagi y ÷ x selalu sama (40).',
  },
  berbalik: {
    color: '#FF4D8D', title: 'Pekerja Bangunan', xs: [1, 2, 3, 4, 6, 8, 12, 24],
    xl: 'Pekerja (orang)', yl: 'Waktu (hari)', y: (x) => 24 / x, k: 'x × y = 24', max: 24,
    story: 'Pekerjaan selesai 24 hari bila dikerjakan 1 orang.',
    ask: 'Pekerja dijadikan 2 kali lipat. Waktunya jadi?', right: 1,
    why: 'Berbalik nilai: x naik, y turun. Hasil kali x × y selalu sama (24).',
  },
};
const OPTS = ['2 kali lebih besar', 'Setengahnya (÷ 2)', 'Tetap sama'];

function Bar({ label, value, max, color, unit }) {
  return (
    <View style={{ marginBottom: 12 }}>
      <View style={st.barHead}><Text style={st.barL}>{label}</Text><Text style={[st.barV, { color }]}>{fmt(value)}</Text></View>
      <View style={st.track}><View style={[st.fill, { width: `${Math.max(3, Math.min(100, (value / max) * 100))}%`, backgroundColor: color }]} /></View>
    </View>
  );
}

export default function Lab({ onBack, onDone }) {
  const [mode, setMode] = useState('senilai');
  const [i, setI] = useState(1);
  const [pick, setPick] = useState(null);
  const m = MODES[mode];
  const x = m.xs[i];
  const y = m.y(x);
  const step = (d) => { const n = Math.max(0, Math.min(m.xs.length - 1, i + d)); if (n !== i) { sfx('click'); setI(n); } };
  const swap = (k) => { if (k === mode) return; sfx('select'); setMode(k); setI(1); setPick(null); };
  const answer = (n) => {
    if (pick !== null) return;
    setPick(n);
    const ok = n === m.right;
    sfx(ok ? 'correct' : 'wrong');
    if (ok) onDone && onDone({ [mode]: true });
  };
  return (
    <PageShell title="Lab" onBack={onBack}>
      <View style={st.tabs}>
        {Object.keys(MODES).map((k) => (
          <Pressable key={k} onPress={() => swap(k)} style={[st.tab, { borderColor: MODES[k].color }, mode === k && { backgroundColor: MODES[k].color }]}>
            <Text style={[st.tabT, mode === k && { color: COLOR.navy }]}>{k === 'senilai' ? 'SENILAI' : 'BERBALIK NILAI'}</Text>
          </Pressable>
        ))}
      </View>

      <Card title={m.title} accent={m.color}>
        <Tag type={mode} />
        <Text style={st.story}>{m.story}</Text>
        <View style={st.stepRow}>
          <PressScale onPress={() => step(-1)} style={[st.stepBtn, { borderColor: m.color }]}><Text style={st.stepT}>−</Text></PressScale>
          <View style={{ alignItems: 'center', flex: 1 }}>
            <Text style={st.xl}>{m.xl}</Text>
            <Text style={[st.xv, { color: m.color }]}>{x}</Text>
          </View>
          <PressScale onPress={() => step(1)} style={[st.stepBtn, { borderColor: m.color }]}><Text style={st.stepT}>+</Text></PressScale>
        </View>
        <Bar label={m.xl} value={x} max={m.xs[m.xs.length - 1]} color={COLOR.ice} />
        <Bar label={m.yl} value={y} max={m.max} color={m.color} />
        <Pop key={mode + x} style={[st.konst, { borderColor: m.color }]}>
          <Text style={st.konstL}>NILAI TETAP</Text>
          <Text style={[st.konstV, { color: m.color }]}>{m.k}</Text>
        </Pop>
      </Card>

      <Card title="Tebak Dulu" accent="#FFD400">
        <Text style={st.story}>{m.ask}</Text>
        {OPTS.map((o, n) => {
          const done = pick !== null;
          const good = n === m.right;
          const bad = done && pick === n && !good;
          return (
            <PressScale key={o} onPress={() => answer(n)} disabled={done} to={0.97} style={[st.opt, done && good && { borderColor: '#3DFFA2', backgroundColor: 'rgba(61,255,162,0.14)' }, bad && { borderColor: '#FF4D4D', backgroundColor: 'rgba(255,77,77,0.14)' }]}>
              <Text style={st.optL}>{'ABC'[n]}</Text>
              <Text style={st.optT}>{o}</Text>
            </PressScale>
          );
        })}
        {pick !== null && (
          <Rise from={10}><Text style={[st.why, { color: pick === m.right ? '#3DFFA2' : '#FF8AB5' }]}>{pick === m.right ? 'BENAR! ' : 'BELUM TEPAT. '}{m.why}</Text></Rise>
        )}
      </Card>
    </PageShell>
  );
}

const st = StyleSheet.create({
  tabs: { flexDirection: 'row', marginBottom: 14 },
  tab: { flex: 1, borderWidth: 2, paddingVertical: 10, alignItems: 'center', marginRight: 8, transform: [{ skewX: '-10deg' }] },
  tabT: { color: COLOR.white, fontWeight: '900', letterSpacing: 1.5, fontSize: 12, transform: [{ skewX: '10deg' }] },
  story: { color: COLOR.text, fontSize: 14, lineHeight: 21, marginBottom: 12 },
  stepRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 14 },
  stepBtn: { width: 56, height: 56, borderWidth: 2, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(2,12,27,0.6)' },
  stepT: { color: COLOR.white, fontSize: 30, fontWeight: '900', includeFontPadding: false, lineHeight: 34 },
  xl: { color: COLOR.ice, fontSize: 11, fontWeight: '900', letterSpacing: 2 },
  xv: { fontSize: 48, fontWeight: '900', fontStyle: 'italic', includeFontPadding: false, lineHeight: 56 },
  barHead: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 },
  barL: { color: COLOR.ice, fontSize: 12, fontWeight: '800' },
  barV: { fontSize: 16, fontWeight: '900' },
  track: { height: 14, backgroundColor: 'rgba(255,255,255,0.1)', transform: [{ skewX: '-20deg' }] },
  fill: { height: '100%' },
  konst: { borderWidth: 2, padding: 10, alignItems: 'center', marginTop: 4, backgroundColor: 'rgba(2,12,27,0.7)' },
  konstL: { color: COLOR.ice, fontSize: 10, fontWeight: '900', letterSpacing: 3 },
  konstV: { fontSize: 26, fontWeight: '900', fontStyle: 'italic' },
  opt: { flexDirection: 'row', alignItems: 'center', borderWidth: 2, borderColor: '#243A6A', padding: 12, marginBottom: 8, backgroundColor: 'rgba(2,12,27,0.55)' },
  optL: { color: COLOR.navy, backgroundColor: COLOR.white, fontWeight: '900', width: 26, textAlign: 'center', marginRight: 12, paddingVertical: 2 },
  optT: { color: COLOR.white, fontWeight: '700', fontSize: 14, flex: 1 },
  why: { fontWeight: '800', fontSize: 13, lineHeight: 20, marginTop: 6 },
});
