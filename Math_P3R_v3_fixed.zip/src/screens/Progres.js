import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { COLOR } from '../theme';
import PageShell, { Card } from '../components/PageShell';
import { QUESTIONS } from '../data';

function Bar({ frac, color }) {
  return (
    <View style={s.track}>
      <View style={{ height: 8, width: `${Math.round(frac * 100)}%`, backgroundColor: color }} />
    </View>
  );
}

export default function Progres({ onBack, progress, user }) {
  const b = progress.bedakan;
  const done = QUESTIONS.filter((q) => progress[q.id]);
  const weakest = done.length
    ? done.map((q) => ({ q, f: progress[q.id].score / progress[q.id].max })).sort((x, y) => x.f - y.f)[0]
    : null;

  return (
    <PageShell title="Progres" onBack={onBack}>
      {user ? <Text style={s.user}>Nama: {user}</Text> : null}
      {progress.game && (
        <Card title="Game — Misi Relasi" accent={COLOR.cyan}>
          <Text style={s.val}>Best: {progress.game.best} / 60</Text>
          <Bar frac={Math.min(1, progress.game.best / 60)} color={COLOR.cyan} />
          <Text style={s.empty}>Dimainkan {progress.game.plays || 1}x · fokus pada arah panah sebelum menghitung.</Text>
        </Card>
      )}

      <Card title="Latihan Membedakan">
        {b ? (
          <>
            <Text style={s.val}>{b.right} / {b.total} benar</Text>
            <Bar frac={b.right / b.total} color={COLOR.cyan} />
          </>
        ) : <Text style={s.empty}>Belum dicoba. Coba GAME untuk pemanasan.</Text>}
      </Card>

      <Card title="Latihan Soal">
        {QUESTIONS.map((q) => {
          const p = progress[q.id];
          return (
            <View key={q.id} style={{ marginBottom: 14 }}>
              <Text style={s.name}>{q.title}</Text>
              {p ? (
                <>
                  <Text style={s.val}>{p.score} / {p.max}   ·   petunjuk {p.hints}x</Text>
                  <Bar frac={p.score / p.max} color={q.type === 'senilai' ? COLOR.cyan : '#FF4D8D'} />
                </>
              ) : <Text style={s.empty}>Belum dikerjakan</Text>}
            </View>
          );
        })}
        {weakest && weakest.f < 1 && (
          <Text style={s.tip}>Perlu diulang: {weakest.q.title}. Buka BELAJAR untuk melihat tabel, diagram panah, dan contoh bertahap.</Text>
        )}
      </Card>
      <Text style={s.note}>Skor tersimpan per nama di perangkat ini (browser atau HP).</Text>
    </PageShell>
  );
}

const s = StyleSheet.create({
  user: { color: COLOR.cyan, fontWeight: '900', fontSize: 16, letterSpacing: 1, marginBottom: 16 },
  name: { color: COLOR.white, fontWeight: '900', fontSize: 14, marginBottom: 4 },
  val: { color: COLOR.ice, fontWeight: '800', fontSize: 14, marginBottom: 6 },
  empty: { color: COLOR.text, opacity: 0.6, fontSize: 13 },
  track: { height: 8, backgroundColor: 'rgba(255,255,255,0.15)' },
  tip: { color: '#FF8AB5', fontWeight: '800', fontSize: 13, marginTop: 4 },
  note: { color: COLOR.text, opacity: 0.5, fontSize: 11 },
});
