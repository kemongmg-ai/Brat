import { QUESTIONS } from './data';

// ============================================================
//  TROPHY, XP & LEVEL  — semua dihitung dari data progress
//  progress[id]      = { score, max, hints, best, attempts, clean, improved }
//  progress.bedakan  = { right, total }
//  progress._trophies = { idTrophy: waktuDibuka(ms) }
// ============================================================

export const TIER = {
  bronze:   { label: 'BRONZE', color: '#E0954F', glow: 'rgba(224,149,79,0.45)' },
  silver:   { label: 'SILVER',    color: '#D5E2F5', glow: 'rgba(213,226,245,0.45)' },
  gold:     { label: 'GOLD',     color: '#FFC83D', glow: 'rgba(255,200,61,0.5)' },
  platinum: { label: 'PLATINUM', color: '#7DF9FF', glow: 'rgba(125,249,255,0.6)' },
};

const done = (p, q) => p[q.id] && (p[q.id].attempts || 1) >= 1;
const perfect = (p, q) => p[q.id] && (p[q.id].best ?? p[q.id].score) === p[q.id].max;
const ofType = (t) => QUESTIONS.filter((q) => q.type === t);
const attemptsOf = (p) => QUESTIONS.reduce((a, q) => a + (p[q.id] ? p[q.id].attempts || 1 : 0), 0);

const qPerfect = (id) => (p) => !!p[id] && (p[id].best ?? p[id].score) === p[id].max;
const gamePlayed = (p) => !!p.game && (p.game.plays || 0) >= 1;
const gameMaster = (p) => !!p.game && (p.game.best || 0) >= 50;

export const TROPHIES = [
  { id: 'first', tier: 'bronze', glyph: '▶', name: 'Dark Hour Begins', desc: 'Finish one problem in the LATIHAN menu. The Dark Hour begins.',
    test: (p) => QUESTIONS.some((q) => done(p, q)) },
  { id: 'gamefirst', tier: 'bronze', glyph: '◆', name: 'First Mission', desc: 'Finish one round of Misi Relasi.', test: gamePlayed },
  { id: 'gamemaster', tier: 'gold', glyph: '✦', name: 'Relation Master', desc: 'Reach 50 points in Misi Relasi.', test: gameMaster },
  { id: 'eye', tier: 'bronze', glyph: '◉', name: 'Eye of the Arcana', desc: 'Answer every case in the GAME menu correctly.',
    test: (p) => !!p.bedakan && p.bedakan.total > 0 && p.bedakan.right === p.bedakan.total },
  { id: 'solo', tier: 'bronze', glyph: '☾', name: 'Soul Unbound', desc: 'Finish one problem without hints, scoring at least half.',
    test: (p) => QUESTIONS.some((q) => p[q.id] && p[q.id].clean) },
  { id: 'comeback', tier: 'silver', glyph: '↑', name: 'Rise from the Shadows', desc: 'Retry a problem and beat your previous score.',
    test: (p) => QUESTIONS.some((q) => p[q.id] && p[q.id].improved) },
  { id: 'diligent', tier: 'silver', glyph: '∞', name: 'Midnight Guardian', desc: 'Complete 6 problems (repeats count).',
    test: (p) => attemptsOf(p) >= 6 },
  { id: 'perfect', tier: 'silver', glyph: '★', name: 'Flawless Calculation', desc: 'Get a perfect score on one problem.',
    test: (p) => QUESTIONS.some((q) => perfect(p, q)) },
  { id: 'kaos', tier: 'silver', glyph: '%', name: 'Efficiency King', desc: 'Perfect score on \"Memilih Pembuat Kaos\".', test: qPerfect('kaos') },
  { id: 'bangunan', tier: 'silver', glyph: '▲', name: 'Architect of Time', desc: 'Perfect score on \"Pekerja dan Waktu\".', test: qPerfect('bangunan') },
  { id: 'bensin', tier: 'silver', glyph: '→', name: 'Precision Navigator', desc: 'Perfect score on \"Bensin Motor\".', test: qPerfect('bensin') },
  { id: 'pizza', tier: 'silver', glyph: '½', name: 'Fair Divider', desc: 'Perfect score on \"Patungan Pizza\".', test: qPerfect('pizza') },
  { id: 'allclear', tier: 'gold', glyph: 'Σ', name: 'Conqueror of Tartarus', desc: 'Complete every problem in the LATIHAN menu at least once.',
    test: (p) => QUESTIONS.every((q) => done(p, q)) },
  { id: 'senilai', tier: 'gold', glyph: '÷', name: 'Master of Ratios', desc: 'Perfect score on all direct-proportion problems.',
    test: (p) => ofType('senilai').length > 0 && ofType('senilai').every((q) => perfect(p, q)) },
  { id: 'berbalik', tier: 'gold', glyph: '×', name: 'Lord of Reciprocity', desc: 'Perfect score on all inverse-proportion problems.',
    test: (p) => ofType('berbalik').length > 0 && ofType('berbalik').every((q) => perfect(p, q)) },
  { id: 'allout', tier: 'platinum', glyph: '✦', name: 'Done and Dusted', desc: 'Perfect score on ALL problems. All-Out Attack, nothing left.',
    test: (p) => QUESTIONS.every((q) => perfect(p, q)) },
];

export const trophyById = (id) => TROPHIES.find((t) => t.id === id);

// Cek trophy yang baru terpenuhi, simpan waktu dibukanya. Mengembalikan { progress, fresh: [id] }
export function awardTrophies(progress) {
  const have = progress._trophies || {};
  const fresh = TROPHIES.filter((t) => !have[t.id] && t.test(progress)).map((t) => t.id);
  if (!fresh.length) return { progress, fresh };
  const now = Date.now();
  const next = { ...have };
  fresh.forEach((id) => { next[id] = now; });
  return { progress: { ...progress, _trophies: next }, fresh };
}

// ---------- XP & level (nama level = Arcana ala Persona) ----------
export const LEVEL_STEP = 40;
export const ARCANA = [
  ['0', 'FOOL'], ['I', 'MAGICIAN'], ['II', 'PRIESTESS'], ['III', 'EMPRESS'], ['IV', 'EMPEROR'],
  ['V', 'HIEROPHANT'], ['VI', 'LOVERS'], ['VII', 'CHARIOT'], ['VIII', 'JUSTICE'], ['IX', 'HERMIT'],
];
export const MAX_LEVEL = ARCANA.length;

export const xpOf = (p) => {
  const q = QUESTIONS.reduce((a, x) => a + (p[x.id] ? (p[x.id].best ?? p[x.id].score) * 10 : 0), 0);
  const b = p.bedakan ? p.bedakan.right * 5 : 0;
  const g = p.game ? (p.game.best || 0) : 0;
  const t = Object.keys(p._trophies || {}).length * 10;
  return q + b + g + t;
};

export function levelOf(xp) {
  const level = Math.min(MAX_LEVEL, 1 + Math.floor(xp / LEVEL_STEP));
  const into = level >= MAX_LEVEL ? LEVEL_STEP : xp - (level - 1) * LEVEL_STEP;
  const [num, name] = ARCANA[level - 1];
  return { level, frac: Math.max(0, Math.min(1, into / LEVEL_STEP)), num, name, maxed: level >= MAX_LEVEL };
}

export const rankOf = (frac) => (frac >= 1 ? 'S' : frac >= 0.75 ? 'A' : frac >= 0.5 ? 'B' : frac > 0 ? 'C' : '–');
export const RANK_TITLE = { S: 'PENAKLUK DARK HOUR', A: 'PENJAGA HITUNGAN', B: 'PEMBURU RASIO', C: 'MURID TARTARUS', '–': '' };
export const RANK_COLOR = { S: '#FFC83D', A: '#00E5FF', B: '#BFEFFF', C: '#FF8AB5', '–': '#3B4A7A' };

export const trophyCount = (p) => Object.keys(p._trophies || {}).length;
