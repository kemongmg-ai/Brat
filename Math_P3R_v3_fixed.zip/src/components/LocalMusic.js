import { useEffect } from 'react';

// expo-audio dimuat "opsional": aplikasi tetap jalan walau belum dipasang (musik lokal saja yang nonaktif).
// Untuk memakai musik lokal: npx expo install expo-audio
let useAudioPlayer = null;
try { useAudioPlayer = require('expo-audio').useAudioPlayer; } catch (e) { useAudioPlayer = null; }

// Musik latar dari file audio lokal (mis. assets/music/bgm.mp3). Tidak butuh internet.
// Dipakai bila MUSIC_FILE di src/config.js diisi.
export default function LocalMusic({ source, playing, volume = 50 }) {
  // nilai useAudioPlayer tidak berubah selama aplikasi hidup, jadi urutan hook tetap konsisten
  const player = useAudioPlayer ? useAudioPlayer(source) : null; // eslint-disable-line react-hooks/rules-of-hooks

  useEffect(() => { if (player) player.loop = true; }, [player]);
  useEffect(() => { if (player) player.volume = Math.max(0, Math.min(1, volume / 100)); }, [player, volume]);
  useEffect(() => {
    if (!player) return;
    try { if (playing) player.play(); else player.pause(); } catch (e) { /* abaikan */ }
  }, [player, playing]);

  return null;
}
