# Math P3R

Aplikasi belajar matematika (Perbandingan Senilai & Berbalik Nilai) dengan UI bertema
Persona 3 Reload. Dibangun dengan **Expo SDK 58** (React Native + Web).

## Pertama kali (di MacBook)
```bash
npm install
npm run setup      # memasang versi library yang cocok dengan SDK 58
npm run doctor     # cek masalah konfigurasi (opsional)
npm run web        # buka di browser (http://localhost:8081)
```
Butuh Node 20 atau lebih baru. Jika muncul `EMFILE: too many open files` di macOS:
`ulimit -n 10240` atau `brew install watchman`.

## Menjalankan di HP Android
Lihat **PANDUAN_UJI_HP.md** (kabel USB, tunnel, atau APK). Ringkasnya:
```bash
npm run usb        # HP dicolok USB, Expo Go terbuka otomatis (tanpa internet)
npm run tunnel     # lewat internet, scan QR di Expo Go
```

## Edit di VS Code
Buka folder ini (`code .`), pasang ekstensi yang disarankan, lalu simpan file:
HP / browser ter-update otomatis (Fast Refresh).
- Teks, menu, karakter, musik, mode performa: `src/config.js`
- Soal, contoh, materi: `src/data.js`
- Warna: `src/theme.js`

## Struktur
```
index.js                    titik masuk
App.js                      navigasi antar layar (state sederhana), tombol Back Android, musik
src/config.js               teks, menu, karakter, PERF_MODE
src/theme.js                palet warna
src/screens/                Lobby, Materi, Bedakan, Langkah, Latihan, Progres, Profil, Login
src/trophies.js             trophy, XP, level, rank
src/data.js                 isi kasus, contoh, dan soal
src/components/             latar bergerak, karakter, menu lobby, efek (Fx), pemutar musik
src/utils/storage.js        penyimpanan progres (localStorage di web, AsyncStorage di HP)
assets/characters/          gambar karakter (tidak di-commit)
```

## Catatan
- Progres kini **tersimpan permanen** di HP (AsyncStorage) dan di browser (localStorage), per nama.
- Musik: isi `MUSIC_URL` di `src/config.js` dengan link YouTube. Kosong = tombol musik hilang.
  Untuk rilis publik, pakai musik bebas royalti.
- Tombol Back Android: dari layar isi kembali ke lobby.

Lihat `PROJECT_NOTES.md` untuk catatan pengembangan.

## Kredit
Karakter Makoto Yuki (Persona 3 Reload) © ATLUS / SEGA. Kredit tampil di lobby.
Aset karakter tidak ikut di-commit (lihat `.gitignore`) dan jangan dipublikasikan ke toko aplikasi.

## Update revisi interaksi
- BGM hanya aktif di LOBBY. Saat masuk BELAJAR, GAME, atau LATIHAN, BGM otomatis berhenti dan kontrol musik disembunyikan.
- Ditambahkan SFX menu pendek untuk BELAJAR, GAME, dan LATIHAN (`assets/sfx/`).
- Simbol kontrol musik, panah game, dan konektor visual dibuat dengan View/Glyph agar konsisten di Android dan tidak bergantung pada font/emoji perangkat.
- GAME dibuat lebih interaktif dengan animasi masuk ronde, pop skor, combo streak, feedback bertahap, dan visual panah.
- Konten game tetap menggunakan konteks yang berasal dari kebutuhan wawancara dan Tabel 2: kaos/vendor, pekerja-waktu, bensin, dan patungan makanan.
